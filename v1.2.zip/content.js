const elementSelector = '.iziToast-wrapper.iziToast-wrapper-bottomCenter';

function removeElement() {
    const elements = document.querySelectorAll(elementSelector);
    elements.forEach(element => element.remove());
    console.log(`Removed ${elements.length} element(s) matching '${elementSelector}'`);
}

chrome.storage.sync.get(['elementRemovalEnabled'], function(result) {
    if (result.elementRemovalEnabled) {
        window.addEventListener('load', removeElement);
    }
});
